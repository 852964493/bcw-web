
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { TemplateRoutingModule } from './template-routing.module';
import { CommonModule } from '@angular/common';
import { TemplateEditComponent } from './edit/edit.component';
import { TemplateListComponent } from './list/list.component';
@NgModule({
  imports: [
    CommonModule,
    TemplateRoutingModule,
    FormsModule,

  ],
  declarations: [TemplateListComponent, TemplateEditComponent]
})
export class TemplateModule { }
