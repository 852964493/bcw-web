import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../services/http-client.service';

@Injectable()
export class TemplateEditService {

	constructor(
		public httpClient: HttpClientService
	) { }


	editRule(template) {
		var postBody = {}
		var postUrl = "";
		if (template.id) {
			postUrl = "api/v1/templates/base/admin/edit";
			postBody = {
				"values": template,
				"condictions": {
					"id": template.id
				}
			}
		} else {
			postUrl = "api/v1/templates/base/admin/add";
			postBody = template;
		}
		return this.httpClient.post(postUrl, postBody);
	}

}
