import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Component, OnInit, Input, DoCheck, Output, EventEmitter } from '@angular/core';
import { TemplateEditService } from './edit.service';

import { Util } from '../../../common/util';
import * as moment from 'moment';
import * as _ from 'lodash';

@Component({
  selector: 'template-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.scss'],
  providers: [TemplateEditService]
})
export class TemplateEditComponent implements OnInit {

  @Input() public template: any = {};
  @Output() refreshList: EventEmitter<any> = new EventEmitter<any>();
  constructor(
    private templateEditService: TemplateEditService,
    private util: Util
  ) {
  }

  ngOnInit() {

    window['$']('.modal').modal({ backdrop: false, show: false });

    window['$']('#textarea').on("keyup", function () {
      window['$']('#textNum').text(window['$']('#textarea').val().length);//这句是在键盘按下时，实时的显示字数
      if (window['$']('#textarea').val().length > 140) {
        window['$']('#textarea').addClass("addborder");
        window['$']('#save').attr("disabled", "disabled");
      }
      if (window['$']('#textarea').val().length < 140) {
        window['$']('#textarea').removeClass("addborder");
        if (window['$']('#name').val().length != 0) {
          window['$']('#save').removeAttr("disabled", "disabled")
        };
      }
    })

      window['$']('.close').on("click", function () {
      window['$']('#textarea').removeClass("addborder");
      window['CKEDITOR'].instances.emailContent.setData("")
      window['CKEDITOR'].instances.webContent.setData("")
    })


    // alert(window['$'](window).width())
    // window['CKEDITOR'].replaceClass = ;
    window['CKEDITOR'].replace('emailContent', {
      // contentsCss: [],
      // customConfig: ''
    });
    window['CKEDITOR'].replace('webContent', {
      // contentsCss: [],
      // customConfig: ''
    });
    
    //  window['CKEDITOR'].config.uiColor = 'red';
    // window['CKEDITOR'].config.skin = 'minimalist';
  }
  close() {
    window['CKEDITOR'].instances.emailContent.setData("")
    window['CKEDITOR'].instances.webContent.setData("")
  }
  ngDoCheck() {
    window['$']('#textNum').text(window['$']('#textarea').val().length);//这句是在刷新的时候仍然显示字数
  }
  tabActive() {
    window['$']("#tab2").removeClass('active');
    window['$']("#tabTwoContent").attr('aria-expanded', "false");
    window['$']("#tab3").removeClass('active');
    window['$']("#tabThreeContent").attr('aria-expanded', "false");
    window['$']("#tab4").removeClass('active');
    window['$']("#tabFourContent").attr('aria-expanded', "false");
    window['$']("#tab1").addClass('active');
    window['$']("#tabOneContent").attr('aria-expanded', "true");
    window['$']("#tab_1").addClass('active');
    window['$']("#tab_2").removeClass('active');
    window['$']("#tab_3").removeClass('active');
    window['$']("#tab_4").removeClass('active');
  }
  createOrUpdate() {
    this.template.emailContent = window['CKEDITOR'].instances.emailContent.document.getBody().getHtml();
    this.template.webContent = window['CKEDITOR'].instances.webContent.document.getBody().getHtml();
    window['CKEDITOR'].instances.emailContent.setData("")
    window['CKEDITOR'].instances.webContent.setData()

    this.templateEditService.editRule(this.template).subscribe(data => {
      if (data) {
        window['swal']('提示', '操作成功', 'success');
        window['$'](".template-edit-modal").modal('hide');
        this.refreshList.emit();
      }
    });

  }

}
