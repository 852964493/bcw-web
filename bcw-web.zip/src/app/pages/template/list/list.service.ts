import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../services/http-client.service';

@Injectable()
export class TemplateListService {

	constructor(
		public httpClient: HttpClientService
	) { }

	list(postBody) {
		return this.httpClient.post('api/v1/templates/base/admin/list', postBody);
	}

	execRule(template) {
		return this.httpClient.post('api/v1/templates/exec', {
			id: template.id
		});
	}
	delTemplate(template) {
		return this.httpClient.post('api/v1/templates/base/admin/del', {
			id: template.id
		});
	}
}
