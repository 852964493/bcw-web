import { ProductRoutingModule } from './product-routing.module';
import { ProductEditComponent } from './edit/edit.component';
import { ProductListComponent } from './list/list.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ProductRoutingModule,
    ReactiveFormsModule
  ],
  declarations: [ProductListComponent, ProductEditComponent]
})
export class ProductModule { }
