import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../services/http-client.service';

@Injectable()
export class ProductListService {

	constructor(
		public httpClient: HttpClientService
	) { }

	list(postBody) {
		return this.httpClient.post('api/v1/products/base/admin/list', postBody);
	}

	execRule(product) {
		return this.httpClient.post('api/v1/products/exec', {
			id: product.id
		});
  }
  delProduct(product){
    return this.httpClient.post('api/v1/products/base/admin/del', {
			id: product.id
		});
  }
}
