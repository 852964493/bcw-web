import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../services/http-client.service';

@Injectable()
export class ProductEditService {

	constructor(
		public httpClient: HttpClientService
	) { }


	editRule(product) {
		var postBody = {}
		var postUrl = "";
		if (product.id) {
			postUrl = "api/v1/products/base/admin/edit";
			postBody = {
				"values": product,
				"condictions": {
					"id": product.id
				}
			}
		} else {
			postUrl = "api/v1/products/base/admin/add";
			postBody = product;
		}
		return this.httpClient.post(postUrl, postBody);
	}

}
