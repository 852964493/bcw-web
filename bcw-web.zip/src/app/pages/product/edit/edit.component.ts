import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Component, OnInit, Input, DoCheck, OnChanges, Output, EventEmitter } from '@angular/core';
import { ProductEditService } from './edit.service';

import { Util } from '../../../common/util';

import * as moment from 'moment';
import * as _ from 'lodash';

@Component({
  selector: 'product-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.scss'],
  providers: [ProductEditService]
})
export class ProductEditComponent implements OnInit {

  @Input() public product: any = {};
  formModel: FormGroup;
  @Output() refreshList: EventEmitter<any> = new EventEmitter<any>();

  constructor(
    private productEditService: ProductEditService,
    private util: Util
  ) {
  }

  ngOnInit() {
    window['$']('.modal').modal({ backdrop: false, show: false });


    window['$']('#startDate').datetimepicker({
      format: "YYYY-MM-DD HH:mm:ss"
    });
    window['$']('#endDate').datetimepicker({
      format: "YYYY-MM-DD HH:mm:ss"
    });
  }

  getstartDate() {
    this.product.startDate = window['$']('#startDate').val();

  }
  getendDate() {
    this.product.endDate = window['$']('#endDate').val();
  }
  onblurgetstartDate() {
    this.product.startDate = window['$']('#startDate').val();
    moment().format();
  }
  onblurgetendDate() {
    this.product.endDate = window['$']('#endDate').val();
  }
  createOrUpdate() {
    this.product.startDate = window['$']('#startDate').val();
    this.product.endDate = window['$']('#endDate').val();


    this.productEditService.editRule(this.product).subscribe(data => {
      if (data) {
        window['swal']('提示', '操作成功', 'success');
        window['$'](".product-edit-modal").modal('hide');
        this.refreshList.emit();
      }
    });

  }

}
