import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../services/http-client.service';

@Injectable()
export class DemoListService {

	constructor(
		public httpClient: HttpClientService
	) { }

	sayHello() {
		// let postBody = {}
		// return this.httpClient.get('api/holderAccount', postBody, {
		// 	isAuthHttp: false
		// });
	}

}
