import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../services/http-client.service';

@Injectable()
export class RuleListService {

	constructor(
		public httpClient: HttpClientService
	) { }


	list(postBody) {
		return this.httpClient.post('api/v1/rules/base/admin/list', postBody);
	}

	editRule(postBody){
		return this.httpClient.post('api/v1/rules/base/admin/edit', postBody);
	}

	execRule(rule) {
		return this.httpClient.post('api/v1/rules/exec', {
			id: rule.id
		});
	}

	delRule(rule){
		return this.httpClient.post('api/v1/rules/base/admin/del',{
			id: rule.id
		});
	}	
}
