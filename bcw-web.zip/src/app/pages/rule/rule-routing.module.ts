import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RuleListComponent } from './list/list.component';
import { RuleEditComponent } from './edit/edit.component';

const routes: Routes = [
	{
		path: '',
		redirectTo: 'list',
		pathMatch: 'full'
	}, {
		path: "list",
		component: RuleListComponent
	}, {
		path: "edit",
		component: RuleEditComponent
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class RuleRoutingModule { }
