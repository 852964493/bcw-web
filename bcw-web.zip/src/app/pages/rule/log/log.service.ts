import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../services/http-client.service';

@Injectable()
export class LogService {

	constructor(public httpClient: HttpClientService) {

	}

	// list(postBody) {
	// 	return this.httpClient.post('api/v1/rules/logs', postBody);
	// }

	// showLog(post) {
	// 	var postBody = {}
	// 	var postUrl = "";
	// 	if (item) {
	// 		postUrl = "api/v1/rules/logs";
	// 		postBody = {
	// 			// "pageIndex": 1,
	// 			// "pageSize": 10,
	// 			"condictions": {
	// 				"id": item.id
	// 			}
	// 		}
	// 	}
	// 	console.info(postBody);
	// 	return this.httpClient.post(postUrl, postBody);
	// }
// api/v1/logs/base/admin/list
		list(postBody) {
		return this.httpClient.post('api/v1/logs/base/admin/list', postBody);
	}
}

