import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { LogService } from './log.service';
import { Util } from '../../../common/util';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'rule-log',
  templateUrl: './log.component.html',
  styleUrls: ['./log.component.scss'],
  providers: [LogService]
})
export class LogComponent implements OnInit {
   public id: any = {};

  public listData: any={
    pageIndex:0,
    pageSize:0,
    list:[],
    total:0
  };

  public pageIndex = 1;

  public pageSize: any = environment.pageSize;

  public pages: any = [];

  constructor(
    private logService: LogService,
    private util: Util
  ) { }

  ngOnInit() {
    // this.loadList(this.pageIndex);
  }

  showLog(item?) {
    this.id=item.id;
    //console.log(item);
    // this.logService.list(item).subscribe(data => {
    //   if (data) {
    //     console.info(data);
    //     this.listData = data.data;
    //   }
    // });
    // let condictions: any = {};
    // this.logService.list({
    //   pageIndex: index ? index : this.pageIndex,
    //   pageSize: parseInt(this.pageSize),
    //   condictions: {
    //     "id": item.id
    //   }
    // }).subscribe(data => {
    //   if (data) {
    //     this.listData = data;
    //     console.info(data);
    //     this.pageIndex = this.listData.pageIndex;
    //     this.pages = this.util.setPage(this.listData.pageSize, this.listData.total, this.pageIndex);
    //   }
    // });
    this.loadList();
  }

  /**
	 * [loadList 加载列表]
	 * @param {[type]} index [description]
	 */
  loadList(index?) {
    let condictions: any = {
      ruleId:this.id
    };
    let order:any="id DESC";
    this.logService.list({
      pageIndex: index ? index : this.pageIndex,
      pageSize: parseInt(this.pageSize),
      condictions: condictions,
      order:order
    }).subscribe(data => {
      if (data) {
        this.listData = data;
        console.info(data);
        this.pageIndex = data.pageIndex;
        this.pages = this.util.setPage(this.listData.pageSize, this.listData.total, this.pageIndex);
      }
    });
  }

	/**
	 * [function 换页]
	 * @param {[type]} type  [description]
	 * @param {[type]} index [description]
	 */
  changePage = function (type, index) {
    var pageCount = Math.ceil(this.listData.total / this.listData.pageSize);
    if (type === 'pre') {
      if (this.pageIndex - 1 > 0) {
        this.pageIndex = this.pageIndex - 1;
        this.showLog(this.pageIndex);
      }
    } else if (type === 'next') {
      if ((this.pageIndex + 1) <= pageCount) {
        this.pageIndex = this.pageIndex + 1;
        this.showLog(this.pageIndex);
      }
    } else {
      this.pageIndex = index;
      this.loadList(this.pageIndex);
    }

  }
}
