import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../services/http-client.service';

@Injectable()
export class RuleEditService {

	constructor(
		public httpClient: HttpClientService
	) { }


	editRule(rule) {
		var postBody = {}
		var postUrl = "";
		if (rule.id) {
			postUrl = "api/v1/rules/base/admin/edit";
			postBody = {
				"values": rule,
				"condictions": {
					"id": rule.id
				}
			}
		} else {
			postUrl = "api/v1/rules/base/admin/add";
			postBody = rule;
		}
		return this.httpClient.post(postUrl, postBody);
	}
	
	testScript(postBody){
		return this.httpClient.post('api/v1/rules/test',postBody);
	}
	testView(postBody){
		return this.httpClient.post('api/v1/logs/base/admin/view',postBody);
	}
}
