import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from "@angular/forms";

import { RuleRoutingModule } from './rule-routing.module';
import { RuleListComponent } from './list/list.component';
import { RuleEditComponent } from './edit/edit.component';
import { LogComponent } from './log/log.component';

@NgModule({
	imports: [
		CommonModule,
		RuleRoutingModule,
		FormsModule
	],
	declarations: [RuleListComponent, RuleEditComponent, LogComponent]
})
export class RuleModule { }
