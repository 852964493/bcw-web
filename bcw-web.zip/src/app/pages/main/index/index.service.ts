import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../services/http-client.service';

@Injectable()
export class IndexService {

	constructor(public httpClient: HttpClientService) { }



	list(postBody?) {
		return this.httpClient.post('api/v1/logs/stat', postBody);
	}
	weekData(postBody?) {
		return this.httpClient.post('api/v1/logs/week', postBody);
	}
}

