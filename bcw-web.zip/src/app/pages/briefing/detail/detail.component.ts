import { Component, OnInit,Input,Pipe, PipeTransform, SecurityContext } from '@angular/core';
import { environment } from '../../../../environments/environment';
import { Util } from '../../../common/util';
import { DomSanitizer } from '@angular/platform-browser'

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.scss']
})
export class DetailComponent implements OnInit {
  @Input() public message: any = {};
  constructor(){ }

  ngOnInit() {
  }
  tabActive() {
		window['$']("#tab2").removeClass('active');
		window['$']("#tabTwoContent").attr('aria-expanded', "false");
		window['$']("#tab1").addClass('active');
		window['$']("#tabOneContent").attr('aria-expanded', "true");
		window['$']("#tab_1").addClass('active');
		window['$']("#tab_2").removeClass('active');
	}
}
