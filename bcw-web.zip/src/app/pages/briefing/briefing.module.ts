import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BriefingRoutingModule } from './briefing-routing.module';
import { ListComponent } from './list/list.component';
import { ListPipe } from './list/list.pipe';
import { DetailComponent } from './detail/detail.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    BriefingRoutingModule,
    ReactiveFormsModule
  ],
  declarations: [ListComponent, ListPipe, DetailComponent]
})
export class BriefingModule { }
