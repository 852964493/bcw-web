import { ListPipe } from './list.pipe';

describe('ListPipe', () => {
  it('create an instance', () => {
    const pipe = new ListPipe();
    expect(pipe).toBeTruthy();
  });
});
