import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../services/http-client.service';

@Injectable()
export class ListService {

  constructor(
     public httpClient: HttpClientService
  ){ }

  list(postBody) {
		return this.httpClient.post('api/v1/reports/list', postBody);
	}

}
