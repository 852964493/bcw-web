import { Component, OnInit ,Input,ViewChild,Pipe, PipeTransform, SecurityContext} from '@angular/core';
import { ListService } from './list.service';
import { environment } from '../../../../environments/environment';
import { Util } from '../../../common/util';
import { DomSanitizer } from '@angular/platform-browser'

import * as moment from 'moment';
import * as _ from 'lodash';
@Component({
  selector: 'app-list',
	templateUrl: './list.component.html',
	styleUrls: ['./list.component.scss'],
  providers: [ListService]
})

export class ListComponent implements OnInit {
  public moon: any = {};

	public listData: any = {};
  
    public pageIndex = 1;
  
    public pageSize: any = environment.pageSize;
  
		public pages: any = [];
		public detail: any = {};
  
	//	public username: any = '';
	//	public createdAt: any ='';
  constructor(
    private listService: ListService,
		private util: Util,
	//	private sanitizer: DomSanitizer,
	 ) {
	}
	

  ngOnInit() {
		this.loadList(this.pageIndex);
		
    window['$']('#startDate').datetimepicker({
      format: "YYYY-MM-DD"
    });
    window['$']('#endDate').datetimepicker({
      format: "YYYY-MM-DD"
    });
	}
  getstartDate() {
   this.moon.startDate = window['$']('#startDate').val();
  }
  getendDate() {
    this.moon.endDate = window['$']('#endDate').val();
  }
  onblurgetstartDate() {
    this.moon.startDate = window['$']('#startDate').val();
    moment().format();
  }
  onblurgetendDate() {
    this.moon.endDate = window['$']('#endDate').val();
  }
	detailContent(type,item){
		let that = this;
		let postBody: any = {
				condictions: {
					"id": item.id
				}}
		//	let mySmsContent = item.smsContent;
		//	let myEmailContent = item.emailContent;
		//	let myWebContent = item.webContent;
	if (type === 'sms') {
		this.detail = _.clone(item.smsContent);
			//window['swal']({
			//	title:"",
			//	text:"<div [innerHTML]='mySmsContent | report'>"+mySmsContent+"</div>",
			//	type:"warning",
	//			html: true,
	//		cancelButtonText: "OK",
	//		})
	}
	else if (type === 'email') {
		this.detail = _.clone(item.emailContent);
	//	window['swal']({
	//		title:"",
	//		text:"<div [innerHTML]='myEmailContent | report'>"+myEmailContent+"</div>",
	//		type:"warning",
	//		html: true,
	//		cancelButtonText: "OK",
	//	})

  }
	else if (type === 'web') {
		this.detail = _.clone(item.webContent);
	//	window['swal']({
	//		title:"",
	//		text:"<div [innerHTML]='myWebContent | report'>"+myWebContent+"</div>" ,
	//		type:"warning",
	//    html: true,
	//		cancelButtonText: "OK",
	//	})
	}
	window['$'](".detail-show-modal").modal('show');
	}

  loadList(index?) {
		let condictions: any = {};
		if (this.moon.startDate,this.moon.endDate) {
			condictions.createdAt = {
				"$gte": "%" + this.moon.startDate + "%" ,
				"$lt": "%" + this.moon.endDate + "%"	
			};
		}
		this.listService.list({
			pageIndex: index ? index : this.pageIndex,
			pageSize: parseInt(this.pageSize),
			condictions: condictions
		}).subscribe(data => {
			if (data) {
				this.listData = data;
				//console.info(data);
				this.pageIndex = this.listData.pageIndex;
				this.pages = this.util.setPage(this.listData.pageSize, this.listData.total, this.pageIndex);
			}
		});
	}

  changePage = function (type, index) {
		var pageCount = Math.ceil(this.listData.total / this.listData.pageSize);
		if (type === 'pre') {
			if (this.pageIndex - 1 > 0) {
				this.pageIndex = this.pageIndex - 1;
				this.loadList(this.pageIndex);
			}
		} else if (type === 'next') {
			if ((this.pageIndex + 1) <= pageCount) {
				this.pageIndex = this.pageIndex + 1;
				this.loadList(this.pageIndex);
			}
		} else {
			this.pageIndex = index;
			this.loadList(this.pageIndex);
		}

	}
}
