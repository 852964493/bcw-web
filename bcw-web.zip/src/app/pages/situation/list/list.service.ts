import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../services/http-client.service';

@Injectable()
export class SituationListService {

  constructor(
    public httpClient: HttpClientService
  ) { }
  list() {
    return this.httpClient.post('api/v1/rules/stat', {});
  }
}
