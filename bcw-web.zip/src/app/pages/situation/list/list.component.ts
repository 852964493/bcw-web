import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { SituationListService } from './list.service';
import * as _ from 'lodash'
import { environment } from '../../../../environments/environment';
import { Util } from '../../../common/util';
import autosize from 'autosize'
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss'],
  providers: [SituationListService]
})
export class ListComponent implements OnInit {
  public situationlist: any = [];
  public newData: any = '';
  constructor(
    private situationListService: SituationListService,

  ) { }

  ngOnInit() {
    this.loadList();
  }

  transForm(content) {
    this.newData = content.replace(/\\n/g, '\n');
    // console.log(this.newData);
    setTimeout(function () {
      autosize(window['$']('textarea'));
    }, 200)
  }

  loadList() {
    this.situationListService.list().subscribe(data => {
      if (data) {
        this.situationlist = data;
      }
    })
  }
}
