import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from '@angular/core';

import { AdminListService } from './list.service';

import { Util } from '../../../common/util';

import { environment } from '../../../../environments/environment';


import * as moment from 'moment';
import * as _ from 'lodash'
@Component({
	selector: 'rule-list',
	templateUrl: './list.component.html',
	styleUrls: ['./list.component.scss'],
	providers: [AdminListService]
})

export class AdminListComponent implements OnInit {


	public listData: any = {};

	public pageIndex = 1;

	public pageSize: any = environment.pageSize;

	public pages: any = [];

	public username: any = '';

	public id: any;

	public selectedAdmin: any = {};

	@Input()
	refresh: any = '';

	constructor(
		private adminListService: AdminListService,
		private util: Util
	) { }

	ngOnInit() {
		this.loadList(this.pageIndex);
	}
	// 删除规则
	delAdmin(item) {
		let that = this;
		// console.log(item.id);
		window['swal']({
			title: "确定?",
			text: "请确认是否要删除：" + item.username + " 指令",
			type: "warning",
			showCancelButton: true,
			confirmButtonColor: "#c9302c",
			confirmButtonText: "确定删除",
			cancelButtonText: "取消",
			// closeOnConfirm: true,
			// html: false
		}, function () {
			that.adminListService.delAdmin(item).subscribe(data => {
				if (data) {
					that.loadList();
				}
			});
		});
	}
	editAdmin(item) {
		//  window['$']("#code").setValue("");
		if (!item) {
			item = {};
			item.type = 'auto'; 	//类型
			item.active = true;
			item.role = 'user';

		}


		this.selectedAdmin = _.clone(item);
		window['$'](".rule-edit-modal").modal('show');


	}

	execAdmin(item) {
		let that = this;
		let postBody: any = {
			condictions: {
				"id": item.id
			},
			values: {
				"active": true
			}
		};
		window['swal']({
			title: "确定?",
			text: "请确认是否要启用账户：" + item.username,
			type: "warning",
			showCancelButton: true,
			// confirmButtonColor: "#DD6B55",
			confirmButtonText: "确定执行",
			cancelButtonText: "取消",
			// closeOnConfirm: true,
			// html: false
		}, function () {
			that.adminListService.editAdmin(postBody).subscribe(data => {
				if (data) {
					window['swal']('提示', '操作成功', 'success');
					that.loadList();
				}
			});
		});
	}

	stopAdmin(item) {
		let that = this;
		let postBody: any = {
			condictions: {
				"id": item.id
			},
			values: {
				"active": false
			}
		}
		window['swal']({
			title: "确定？",
			text: "请确认是否要停止账户：" + item.username,
			type: "warning",
			showCancelButton: true,
			// confirmButtonColor: "#DD6B55",
			confirmButtonText: "确定",
			cancelButtonText: "取消",
		}, function () {
			that.adminListService.editAdmin(postBody).subscribe(data => {
				if (data) {
					window['swal']('提示', '操作成功', 'success');
					that.loadList();
				}
			})
		})
	}

	// 显示日志modal
	// showLog(item) {
	// 	// id = 5;
	// 	console.log(item.id);
	// 	this.logComponent.showLog(item);
	// 	window['$'](".rule-log-modal").modal('show');
	// }
	/**
	 * [loadList 加载列表]
	 * @param {[type]} index [description]
	 */
	loadList(index?) {
		let condictions: any = {};
		if (this.username) {
			condictions.username = {
				"$like": "%" + this.username + "%"
			};
		}
		this.adminListService.list({
			pageIndex: index ? index : this.pageIndex,
			pageSize: parseInt(this.pageSize),
			condictions: condictions
		}).subscribe(data => {
			if (data) {
				this.listData = data;
				//console.info(data);
				this.pageIndex = this.listData.pageIndex;
				this.pages = this.util.setPage(this.listData.pageSize, this.listData.total, this.pageIndex);
			}
		});
	}

	/**
	 * [function 换页]
	 * @param {[type]} type  [description]
	 * @param {[type]} index [description]
	 */
	changePage = function (type, index) {
		var pageCount = Math.ceil(this.listData.total / this.listData.pageSize);
		if (type === 'pre') {
			if (this.pageIndex - 1 > 0) {
				this.pageIndex = this.pageIndex - 1;
				this.loadList(this.pageIndex);
			}
		} else if (type === 'next') {
			if ((this.pageIndex + 1) <= pageCount) {
				this.pageIndex = this.pageIndex + 1;
				this.loadList(this.pageIndex);
			}
		} else {
			this.pageIndex = index;
			this.loadList(this.pageIndex);
		}

	}

}
