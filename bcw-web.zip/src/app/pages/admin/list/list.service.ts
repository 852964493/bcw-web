import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../services/http-client.service';

@Injectable()
export class AdminListService {

	constructor(
		public httpClient: HttpClientService
	) { }


	list(postBody) {
		return this.httpClient.post('api/v1/users/base/admin/list', postBody);
	}

	editAdmin(postBody){
		return this.httpClient.post('api/v1/users/base/admin/edit', postBody);
	}
	execAdmin(admin) {
		return this.httpClient.post('api/v1/users/exec', {
			id: admin.id
		});
	}

	delAdmin(admin){
		return this.httpClient.post('api/v1/users/base/admin/del',{
			id: admin.id
		});
	}
}
