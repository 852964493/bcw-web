import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from "@angular/forms";

import { AdminRoutingModule } from './admin-routing.module';
import { AdminListComponent } from './list/list.component';
import { AdminEditComponent } from './edit/edit.component';



@NgModule({
	imports: [
		CommonModule,
		AdminRoutingModule,
		FormsModule
	],
	declarations: [AdminListComponent, AdminEditComponent]
})
export class AdminModule { }
