import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../services/http-client.service';

@Injectable()
export class AdminEditService {

	constructor(
		public httpClient: HttpClientService
	) { }


	editAdmin(admin) {
		var postBody = {}
		var postUrl = "";
		if (admin.id) {
			postUrl = "api/v1/users/base/admin/edit";
			postBody = {
				"values": admin,
				"condictions": {
					"id": admin.id
				}
			}
		} else {
			postUrl = "api/v1/users/base/admin/add";
			postBody = admin;
		}
		return this.httpClient.post(postUrl, postBody);
	}
	
}
