import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AdminEditService } from './edit.service';

import { Util } from '../../../common/util';

import * as moment from 'moment';
import * as _ from 'lodash'
@Component({
	selector: 'admin-edit',
	templateUrl: './edit.component.html',
	styleUrls: ['./edit.component.scss'],
	providers: [AdminEditService]
})
export class AdminEditComponent implements OnInit {
	@Input() public admin: any = {};

	@Input() public loadList: any;

	@Output() refreshList: EventEmitter<any> = new EventEmitter<any>();

	constructor(
		private adminEditService: AdminEditService,
		private util: Util
	) { }


	tabActive() {
		// console.log('111');
		window['$']("#tab2").removeClass('active');
		window['$']("#tabTwoContent").attr('aria-expanded', "false");
		window['$']("#tab1").addClass('active');
		window['$']("#tabOneContent").attr('aria-expanded', "true");
		window['$']("#tab_1").addClass('active');
		window['$']("#tab_2").removeClass('active');
		// console.info(window['$'](".CodeMirror-line span").text());
		// if (window['$'](".CodeMirror-line span").text() == null) {
		// console.log("this is null");
		//  window['$']('#save_btn').attr("disabled","disabled");
		// .attr("required",true);
		// }
	}

	ngOnInit() {
		// 执行规则
		window['$']("#cron").cronGen();
		window['$']('.modal').modal({backdrop: false, show:false});

	}





	createOrUpdate() {

		this.adminEditService.editAdmin(this.admin).subscribe(data => {
			if (data) {
				console.log(this.admin);
				window['swal']('提示', '操作成功', 'success');
				window['$'](".rule-edit-modal").modal('hide');
				this.refreshList.emit();
				this.tabActive();
			}
		});


	}

}
