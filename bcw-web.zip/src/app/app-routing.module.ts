import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LayoutComponent } from './pages/global/layout/layout.component';

import { AuthGuardService } from './services/auth-guard.service';


const routes: Routes = [
  {
    path: '',
    loadChildren: './pages/login/login.module#LoginModule'
  },
  {
    path: 'pages',
    component: LayoutComponent,
    canActivate: [AuthGuardService],
    children: [
      {
        path: 'main',
        loadChildren: './pages/main/main.module#MainModule'
      },
      {
        path: 'situation',
        loadChildren: './pages/situation/situation.module#SituationModule'
      },
      {
        path: 'demo',
        loadChildren: './pages/demo/demo.module#DemoModule'
      },
      {
        path: 'rule',
        loadChildren: './pages/rule/rule.module#RuleModule'
      },
      {
        path: 'product',
        loadChildren: './pages/product/product.module#ProductModule'
      },
      {
        path: 'template',
        loadChildren: './pages/template/template.module#TemplateModule'
      },
      {
        path: 'admin',
        loadChildren: './pages/admin/admin.module#AdminModule'
      },
      {
        path: 'briefing',
        loadChildren: './pages/briefing/briefing.module#BriefingModule'
      }

    ]
  },
  // { path: '**', component: NoFoundComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
}
