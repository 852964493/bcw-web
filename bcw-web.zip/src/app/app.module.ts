import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
// global layout
import { LayoutComponent } from './pages/global/layout/layout.component';
// common widget
import { AppHeaderComponent } from './widgets/header/header.component';
import { AppSidebarComponent } from './widgets/sidebar/sidebar.component';
import { AppFooterComponent } from './widgets/footer/footer.component';
import { AppBreadcrumbComponent } from './widgets/breadcrumb/breadcrumb.component';


// common service
import { AuthGuardService } from './services/auth-guard.service';
import { HttpClientService } from './services/http-client.service';
import { MissionService } from './services/mission.service';
import { Util } from './common/util';


import { HttpModule, Http, RequestOptions } from '@angular/http';
import { AuthHttp, AuthConfig } from 'angular2-jwt';
/**
 * [authHttpServiceFactory 定义存储token的位置和名称]
 * @param {Http}           http    [description]
 * @param {RequestOptions} options [description]
 */
export function authHttpServiceFactory(http: Http, options: RequestOptions) {
  return new AuthHttp(new AuthConfig({
    tokenName: 'token',
    tokenGetter: (() => sessionStorage.getItem('token')),
    globalHeaders: [{ 'Content-Type': 'application/json' }],
  }), http, options);
}

@NgModule({
  declarations: [
    AppComponent,
    LayoutComponent,
    AppHeaderComponent,
    AppSidebarComponent,
    AppFooterComponent,
    AppBreadcrumbComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    AppRoutingModule
  ],
  providers: [{
    provide: AuthHttp,
    useFactory: authHttpServiceFactory,
    deps: [Http, RequestOptions]
  }, AuthGuardService, HttpClientService, MissionService, Util],
  bootstrap: [AppComponent]
})
export class AppModule {
}
