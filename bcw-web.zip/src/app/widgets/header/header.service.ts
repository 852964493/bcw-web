import { Injectable,EventEmitter ,Output} from '@angular/core';

@Injectable()
export class HeaderService {
    
  constructor() {}

}
