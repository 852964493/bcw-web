import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { environment } from '../../../environments/environment';
import { HeaderService } from './header.service';
import io from 'socket.io-client/dist/socket.io.js';
import { MissionService } from '../../services/mission.service';


@Component({
	selector: 'app-header',
	templateUrl: './header.component.html',
	styleUrls: ['./header.component.scss'],
	providers: [HeaderService]
})
export class AppHeaderComponent implements OnInit {

	@Input() public layoutMode: String = "";

	@Input() public links: Array<any> = [];

	@Input() public currentUrl: String = "";

	@Input() public nav;

	@Input() public user;

	completeCount: any;
	public server: String = environment.server;
	constructor(
		public router: Router,
		public headerService: HeaderService,
		public missionService: MissionService
	) {

	}


	ngOnInit() {
		let that = this;
		var token = sessionStorage.getItem('token');
		var socket = io(this.server, {
			// Send auth token on connection, you will need to DI the Auth service above
			'query': 'token=' + token
		});
		socket.on('connect', function () {
			console.log('socket连接成功')
		});

		socket.on("broadcast", (data: any) => {
			that.missionService.broadcast(data);
			//console.log(data);
			//console.log(data.completeCount);
			// this.headerService.completeCount = data.completeCount;
			//console.log("service"+this.headerService.completeCount);
		}
		);
		socket.on("bcw-push", (data: any) => {
			// console.log('-----bcw-push-----');
			// console.log(data);
			data = JSON.parse(data);
			window['swal']({
				type: "warning",
				title: "预警提醒",
				text: data.content,
				html: true
			});
		}
		);
	}
	removeSession() {
		sessionStorage.removeItem('token');
		sessionStorage.removeItem('user');
		this.router.navigateByUrl("");
	}
}
